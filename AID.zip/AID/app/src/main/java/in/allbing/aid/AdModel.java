package in.allbing.aid;

public class AdModel
{
    String Username;
    String AdID;

    public AdModel() {
    }

    public String getUsername() {
        return Username;
    }

    public void setUsername(String username) {
        Username = username;
    }

    public String getAdID() {
        return AdID;
    }

    public void setAdID(String adID) {
        AdID = adID;
    }
}
