package in.allbing.aid;

public class DataModel {
    String Username;

    public DataModel(String username) {
        Username = username;
    }

    public String getUsername() {
        return Username;
    }

    public void setUsername(String username) {
        Username = username;
    }
}
